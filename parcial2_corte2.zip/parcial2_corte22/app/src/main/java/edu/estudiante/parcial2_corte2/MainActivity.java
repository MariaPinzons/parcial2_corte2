package edu.estudiante.parcial2_corte2;

import static android.widget.Toast.LENGTH_LONG;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText txt_fifo;
    Button btn_ingresar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txt_fifo = findViewById(R.id.txt_textFifo);
        btn_ingresar = findViewById(R.id.btn_ingresar);


        btn_ingresar.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {

               Toast.makeText(MainActivity.this, txt_fifo.getText(), LENGTH_LONG).show();
            }
        });
    }
}